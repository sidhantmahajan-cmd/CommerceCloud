export const environment = {
  production: true,
  occBaseUrl: undefined
};
